#include<stdio.h>
#include<conio.h>
#include<graphics.h>
int main()
{
	int gd= DETECT, gm;
	initgraph(&gd,&gm,(char*)"");
	bar(100,100,50,250);
	getch();
	closegraph();
	return 0;
}
