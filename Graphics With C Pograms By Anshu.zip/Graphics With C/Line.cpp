#include<stdio.h>
#include<conio.h>
#include<graphics.h>
int main()
{
	int gd= DETECT, gm;
	initgraph(&gd,&gm,(char*)"");
	line(100,100,200,200);
	line(100,150,200,250);
	getch();
	closegraph();
	return 0;
}
