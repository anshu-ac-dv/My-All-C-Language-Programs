#include<stdio.h>
#include<conio.h>
#include<graphics.h>
int main()
{
	int gd= DETECT, gm;
	initgraph(&gd,&gm,(char*)"");
	arc(100,100,0,35,150);
	getch();
	closegraph();
	return 0;
}
