#include<stdio.h>
#include<conio.h>
#include<graphics.h>
int main()
{
	int gd= DETECT, gm;
	initgraph(&gd,&gm,(char*)"");
	ellipse(100,100,0,360,50,25);
	ellipse(100,200,0,360,50,25);
	line(50,100,50,200);
	line(150,100,150,200);
	getch();
	closegraph();
	return 0;
}
