#include<stdio.h>
#include<conio.h>
#include<graphics.h>
int main()
{
	int gd= DETECT, gm;
	initgraph(&gd,&gm,(char*)"");
	line(150,100,100,200);
	line(100,200,200,200);
	line(200,200,150,100);
	getch();
	closegraph();
	return 0;
}
