#include<stdio.h>
#include<conio.h>
#include<graphics.h>
int main()
{
	int gd= DETECT, gm;
	initgraph(&gd,&gm,(char*)"");
	line(100,100,200,200);
	line(100,150,200,0);
	line(100,150,0,200);
	line(100,0,200,200);
	getch();
	closegraph();
	return 0;
}
