#include<stdio.h>
#include<conio.h>
#include<graphics.h>
int main()
{
	int gd= DETECT, gm,points[]={310,150,420,300,250,320,150};
	initgraph(&gd,&gm,(char*)"");
	drawpoly(4,points);
	getch();
	closegraph();
	return 0;
}
