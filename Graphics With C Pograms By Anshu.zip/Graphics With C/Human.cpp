#include<stdio.h>
#include<conio.h>
#include<graphics.h>
int main()
{
	int gd = DETECT,gm;
	initgraph(&gd,&gm,(char*)"");
	circle(300,100,50);
	getch();
	closegraph();
	return 0;
}
